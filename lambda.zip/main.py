#Main initialising code

def lambda_handler(event,context):
    print('Running test lambda')
    print(event)
    print(context)