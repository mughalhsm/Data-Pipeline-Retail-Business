#Main initialising code
def lambda_hander(event, context):
    print(event)